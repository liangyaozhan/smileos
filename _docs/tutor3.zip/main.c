const char *tutorial3;

void main()
{
  clrscr();
  print(tutorial3);

  for(;;);
}

const char *tutorial3 = "MuOS Tutorial 3";
