No restrictions are placed on the use of these files.

NOTICE: you agree(whether you have read this or not) to not hold anyone responsible for anything that might happen due to the use of these files.

Bona Fide OS Development:
http://osdev.redir.net